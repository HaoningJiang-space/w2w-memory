`timescale 1ns/1ps
module endpoint_ppa_dup (input wire clk,rst,cfg_shared_direction,
    input wire native_valid,native_role,native_shared_direction,
    input wire [255:0] native_data,output wire native_ready,
    input wire [2:0] sink_ready,output wire [2:0] sink_valid,
    output wire [767:0] sink_data,output wire [2:0] hb_valid,hb_ready,
    output wire [767:0] hb_data,output wire [11:0] hb_units);
    wire [255:0] hd; wire [159:0] ld,rd;
    mapped_pruned_dup_l tx (.clk(clk),.rst(rst),.cfg_shared_direction(cfg_shared_direction),
      .native_valid(native_valid),.native_role(native_role),
      .native_shared_direction(native_shared_direction),.native_data(native_data),
      .native_ready(native_ready),.hb_valid(hb_valid),.hb_ready(hb_ready),
      .home_data(hd),.left_data(ld),.right_data(rd),
      .home_units(hb_units[3:0]),.left_units(hb_units[7:4]),.right_units(hb_units[11:8]));
    assign hb_data={96'b0,rd,96'b0,ld,hd};
    endpoint_rx #(.WIDTH(256)) rx0 (
      .clk(clk),.rst(rst),.beat_valid(hb_valid[0]),.beat_ready(hb_ready[0]),
      .beat_data(hd),.beat_units(hb_units[0+:4]),
      .word_valid(sink_valid[0]),.word_ready(sink_ready[0]),
      .word_data(sink_data[0+:256]));
    endpoint_rx #(.WIDTH(160)) rx1 (
      .clk(clk),.rst(rst),.beat_valid(hb_valid[1]),.beat_ready(hb_ready[1]),
      .beat_data(ld),.beat_units(hb_units[4+:4]),
      .word_valid(sink_valid[1]),.word_ready(sink_ready[1]),
      .word_data(sink_data[256+:256]));
    endpoint_rx #(.WIDTH(160)) rx2 (
      .clk(clk),.rst(rst),.beat_valid(hb_valid[2]),.beat_ready(hb_ready[2]),
      .beat_data(rd),.beat_units(hb_units[8+:4]),
      .word_valid(sink_valid[2]),.word_ready(sink_ready[2]),
      .word_data(sink_data[512+:256]));
endmodule
module endpoint_ppa_cfg (input wire clk,rst,cfg_shared_direction,
    input wire native_valid,native_role,native_shared_direction,
    input wire [255:0] native_data,output wire native_ready,
    input wire [2:0] sink_ready,output wire [2:0] sink_valid,
    output wire [767:0] sink_data,output wire [2:0] hb_valid,hb_ready,
    output wire [767:0] hb_data,output wire [11:0] hb_units);
    wire [255:0] hd; wire [159:0] ld,rd;
    mapped_configurable tx (.clk(clk),.rst(rst),.cfg_shared_direction(cfg_shared_direction),
      .native_valid(native_valid),.native_role(native_role),
      .native_shared_direction(native_shared_direction),.native_data(native_data),
      .native_ready(native_ready),.hb_valid(hb_valid),.hb_ready(hb_ready),
      .home_data(hd),.left_data(ld),.right_data(rd),
      .home_units(hb_units[3:0]),.left_units(hb_units[7:4]),.right_units(hb_units[11:8]));
    assign hb_data={96'b0,rd,96'b0,ld,hd};
    endpoint_rx #(.WIDTH(256)) rx0 (
      .clk(clk),.rst(rst),.beat_valid(hb_valid[0]),.beat_ready(hb_ready[0]),
      .beat_data(hd),.beat_units(hb_units[0+:4]),
      .word_valid(sink_valid[0]),.word_ready(sink_ready[0]),
      .word_data(sink_data[0+:256]));
    endpoint_rx #(.WIDTH(160)) rx1 (
      .clk(clk),.rst(rst),.beat_valid(hb_valid[1]),.beat_ready(hb_ready[1]),
      .beat_data(ld),.beat_units(hb_units[4+:4]),
      .word_valid(sink_valid[1]),.word_ready(sink_ready[1]),
      .word_data(sink_data[256+:256]));
    endpoint_rx #(.WIDTH(160)) rx2 (
      .clk(clk),.rst(rst),.beat_valid(hb_valid[2]),.beat_ready(hb_ready[2]),
      .beat_data(rd),.beat_units(hb_units[8+:4]),
      .word_valid(sink_valid[2]),.word_ready(sink_ready[2]),
      .word_data(sink_data[512+:256]));
endmodule
