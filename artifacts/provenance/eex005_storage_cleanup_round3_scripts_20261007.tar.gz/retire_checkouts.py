"""Archive clean, terminated test checkouts as verified Git bundles, then retire."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import tempfile
from dedupe_extents import digest, free, live_refs

BASE=Path('/home/wangziheng/TA-PPAAS/tmp/experiments/ThermoDSE')
OUT=Path('/home/wangziheng/Video/w2w-finite-read-20261007/memory_results/cleanup_round3')
ARCHIVE=BASE/'retired_sources_20261007'
HD=BASE/'parent-ttrace-576dd02-4T2xSR/checkout/external/hdmoe'

def git(path,*args):
    return subprocess.check_output(['git','-C',str(path),*args],stderr=subprocess.PIPE,text=True).strip()

def checked_clean(p):
    if git(p,'status','--porcelain','--untracked-files=all'):
        raise RuntimeError('Dirty checkout '+str(p))
    ignored=git(p,'ls-files','--others','--ignored','--exclude-standard').splitlines()
    if any('/__pycache__/' not in ('/'+f) or not f.endswith('.pyc') for f in ignored):
        raise RuntimeError(('Non-cache ignored files',str(p),ignored[:10]))

def bundle(p,name):
    path=ARCHIVE/(name+'.bundle')
    if not path.exists():git(p,'bundle','create',str(path),'--all','HEAD')
    shallow_path=Path(git(p,'rev-parse','--git-path','shallow'))
    if not shallow_path.is_absolute():shallow_path=p/shallow_path
    shallow=shallow_path.read_text() if shallow_path.exists() else ''
    if shallow:Path(str(path)+'.shallow').write_text(shallow)
    # A fresh bare clone proves this bundle is self-contained and checks its objects.
    with tempfile.TemporaryDirectory(dir=str(OUT),prefix='restore-check-') as d:
        restored=Path(d)/'repo.git'
        subprocess.run(['git','clone','--bare',str(path),str(restored)],check=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        # Git bundle v2 does not transport a shallow checkout's boundary file.
        # Preserve it explicitly; do not invent unavailable parent history.
        if shallow:(restored/'shallow').write_text(shallow)
        git(restored,'fsck','--full')
        assert git(restored,'rev-parse','HEAD')==git(p,'rev-parse','HEAD')
        assert git(restored,'rev-parse','HEAD^{tree}')==git(p,'rev-parse','HEAD^{tree}')
    return dict(path=str(path),sha256=digest(path),bytes=path.stat().st_size,
                head=git(p,'rev-parse','HEAD'),tree=git(p,'rev-parse','HEAD^{tree}'),
                shallow_commits=shallow.splitlines(),restore_verified=True)

def refs_outside(targets):
    found=[]
    targets=[str(x) for x in targets]
    for d,ds,fs in os.walk('/home/wangziheng'):
        if any(d==t or d.startswith(t+'/') for t in targets):ds[:]=[];continue
        ds[:]=[n for n in ds if n!='.git']
        for n in ds+fs:
            p=os.path.join(d,n)
            if os.path.islink(p):
                dest=os.path.realpath(p)
                if any(dest==t or dest.startswith(t+'/') for t in targets):found.append(dict(link=p,target=dest))
    return found

def repos_under(p):
    repos=[]
    for d,ds,fs in os.walk(p):
        if '.git' in ds or '.git' in fs:repos.append(Path(d))
        ds[:]=[n for n in ds if n!='.git']
    return sorted(repos,key=lambda p:len(p.parts))

def check_entry(e):
    p=Path(e['path'])
    if p.is_symlink() or p.parent.parent!=BASE or p.name not in ('source','checkout'):
        raise RuntimeError('Outside allowlist '+str(p))
    for r in e['repositories']:
        rp=p/r['relative_path'];checked_clean(rp)
        assert git(rp,'rev-parse','HEAD')==r['head']
        assert git(rp,'rev-parse','HEAD^{tree}')==r['tree']
    for rel in e['terminal_markers']:
        assert (p.parent/rel).is_file()

def allocated(paths):
    seen=set();total=0
    for path in paths:
        for d,ds,fs in os.walk(path):
            for n in fs:
                p=Path(d)/n;s=p.lstat();key=(s.st_dev,s.st_ino)
                if key not in seen:seen.add(key);total+=s.st_blocks*512
    return total

def prepare():
    if (OUT/'checkout_plan.json').exists():raise RuntimeError('Plan exists')
    ARCHIVE.mkdir(exist_ok=True)
    before=free()
    checked_clean(HD)
    assert git(HD,'fsck','--no-reflogs','--unreachable')==''
    hd_bundle=bundle(HD,'hdmoe-66b84d7')
    entries=[];skipped=[]
    for batch in sorted(BASE.iterdir()):
        if not batch.is_dir() or batch==ARCHIVE:continue
        p=next((batch/leaf for leaf in ('checkout','source') if (batch/leaf/'.git').is_dir()),None)
        if p is None:continue
        terminal=[f.name for f in batch.iterdir() if f.is_file() and ('exit' in f.name or 'end_time' in f.name)]
        if not terminal:
            skipped.append({'path':str(p),'reason':'No top-level terminal marker; retained'})
            continue
        checked_clean(p)
        assert git(p,'fsck','--no-reflogs','--unreachable')==''
        root_bundle=bundle(p,batch.name)
        repos=[]
        for repo in repos_under(p):
            checked_clean(repo)
            h,t=git(repo,'rev-parse','HEAD'),git(repo,'rev-parse','HEAD^{tree}')
            b=root_bundle if repo==p else hd_bundle
            if (h,t)!=(b['head'],b['tree']):raise RuntimeError('Unarchived nested repository '+str(repo))
            repos.append({'relative_path':str(repo.relative_to(p)),'head':h,'tree':t,'bundle':b['path'],
                          'bundle_sha256':b['sha256'],'shallow_commits':b['shallow_commits']})
        e={'path':str(p),'terminal_markers':terminal,'repositories':repos,'source_bundle':root_bundle}
        check_entry(e);entries.append(e)
    targets=[Path(e['path']) for e in entries]
    active=live_refs(targets);syms=refs_outside(targets)
    if active or syms:raise RuntimeError(('Referenced target',active,syms))
    plan=dict(entries=entries,skipped=skipped,hdmoe_bundle=hd_bundle,free_before_archives=before,
              allocated_checkout_bytes=allocated(targets),archive_bytes=allocated([ARCHIVE]),
              active_references=active,external_symlink_references=syms,
              scope='Only clean checkout/source leaves of terminated tests; batch logs, inputs, results, tools and existing bundles retained')
    (OUT/'checkout_plan.json').write_text(json.dumps(plan,indent=2)+'\n')
    (ARCHIVE/'RESTORE.json').write_text(json.dumps(plan,indent=2)+'\n')
    print(json.dumps({'checkouts':len(entries),'bytes':plan['allocated_checkout_bytes'],'archive_bytes':plan['archive_bytes'],'skipped':skipped}),flush=True)

def apply():
    if (OUT/'checkout_receipt.json').exists():raise RuntimeError('Receipt exists')
    plan=json.loads((OUT/'checkout_plan.json').read_text())
    for e in plan['entries']:check_entry(e)
    targets=[Path(e['path']) for e in plan['entries']]
    refs=live_refs(targets);syms=refs_outside(targets)
    if refs or syms:raise RuntimeError(('Target in use',refs,syms))
    bundles={r['bundle']:r['bundle_sha256'] for e in plan['entries'] for r in e['repositories']}
    for path,sha in bundles.items():assert digest(path)==sha,path
    before=free();removed=[]
    with (OUT/'checkout_journal.jsonl').open('x') as journal:
        for e in plan['entries']:
            check_entry(e)
            refs=live_refs([Path(e['path'])])
            if refs:raise RuntimeError(refs)
            shutil.rmtree(e['path'])
            removed.append(e['path']);journal.write(json.dumps({'removed':e['path']})+'\n');journal.flush()
    for path,sha in bundles.items():assert digest(path)==sha,path
    after=free()
    receipt=dict(plan,removed=removed,free_before_delete=before,free_after_delete=after,
                 observed_free_delta=after-before,bundles_reverified=True)
    (OUT/'checkout_receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
    (ARCHIVE/'CLEANUP_RECEIPT.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps({'removed_checkouts':len(removed),'observed_free_delta':after-before,'archive':str(ARCHIVE)}),flush=True)

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--apply',action='store_true');args=parser.parse_args()
    apply() if args.apply else prepare()
