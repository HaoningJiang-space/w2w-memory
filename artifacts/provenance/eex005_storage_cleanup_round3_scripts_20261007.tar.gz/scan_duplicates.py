import collections
import hashlib
import json
import os
from pathlib import Path
import time

ROOTS = ['/home/wangziheng/wafer_simulator/runs', '/home/wangziheng/thermal_hbt']
OUT = Path('/home/wangziheng/Video/w2w-finite-read-20261007/memory_results/cleanup_round3')
OUT.mkdir(exist_ok=True)
report = []
for root in ROOTS:
    sizes = collections.defaultdict(list)
    seen = set()
    for d, dirs, files in os.walk(root):
        dirs[:] = [n for n in dirs if n != '.git']
        for name in files:
            p = Path(d) / name
            if p.is_symlink() or not p.is_file():
                continue
            if 'thermal_hbt' in root and p.suffix != '.npy':
                continue
            s = p.stat()
            key = (s.st_dev, s.st_ino)
            if s.st_size < 8*1024**2 or key in seen:
                continue
            seen.add(key)
            sizes[s.st_size].append(str(p))
    groups = []
    for size, paths in sizes.items():
        if len(paths) < 2:
            continue
        samples = collections.defaultdict(list)
        for p in paths:
            with open(p, 'rb') as f:
                prefix = f.read(65536)
                f.seek(-65536, 2)
                suffix = f.read(65536)
            samples[hashlib.sha256(prefix+suffix).hexdigest()].append(p)
        for sample in samples.values():
            if len(sample) < 2:
                continue
            hashes = collections.defaultdict(list)
            for p in sample:
                before = os.stat(p)
                h = hashlib.sha256()
                with open(p, 'rb') as f:
                    for block in iter(lambda: f.read(4*1024**2), b''):
                        h.update(block)
                after = os.stat(p)
                if (before.st_mtime_ns, before.st_size, before.st_ino) != (after.st_mtime_ns, after.st_size, after.st_ino):
                    raise RuntimeError('File changed: '+p)
                hashes[h.hexdigest()].append(dict(path=p, bytes=size, blocks=after.st_blocks,
                                                 inode=after.st_ino, links=after.st_nlink,
                                                 mtime_ns=after.st_mtime_ns))
            for digest, files in hashes.items():
                if len(files)>1:
                    groups.append(dict(sha256=digest, files=files))
    report.append(dict(root=root, groups=groups))
    (OUT/'duplicates.json').write_text(json.dumps(report, indent=2)+'\n')
    print(json.dumps(dict(root=root, duplicate_groups=len(groups), logical_redundancy=sum(g['files'][0]['bytes']*(len(g['files'])-1) for g in groups))), flush=True)
