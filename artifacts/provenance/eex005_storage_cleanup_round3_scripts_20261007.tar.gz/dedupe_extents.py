"""Release identical XFS extents; preserve independent files and all contents."""
import fcntl
import hashlib
import json
import os
from pathlib import Path
import platform
import struct
import time

OUT = Path('/home/wangziheng/Video/w2w-finite-read-20261007/memory_results/cleanup_round3')
FIDEDUPERANGE = 0xC0189436
CHUNK = 16*1024**2
PROTECTED_DAEMONS = set()

def digest(p):
    h = hashlib.sha256()
    with open(p, 'rb') as f:
        for block in iter(lambda: f.read(4*1024**2), b''):
            h.update(block)
    return h.hexdigest()

def free():
    s=os.statvfs(OUT)
    return s.f_bavail*s.f_frsize

def live_refs(paths):
    paths={str(p) for p in paths}
    found=[]
    for proc in Path('/proc').iterdir():
        if not proc.name.isdigit() or int(proc.name)==os.getpid():continue
        try:
            if proc.stat().st_uid!=os.getuid():continue
            links=[proc/'cwd',proc/'exe',*list((proc/'fd').iterdir())]
            for link in links:
                try:
                    p=os.readlink(link).removesuffix(' (deleted)')
                    if p in paths or any(p.startswith(t+'/') for t in paths):found.append((proc.name,p))
                except FileNotFoundError:pass
            for line in (proc/'maps').read_text().splitlines():
                fields=line.split(None,5)
                if len(fields)==6:
                    p=fields[-1]
                    if p in paths or any(p.startswith(t+'/') for t in paths):found.append((proc.name,p))
        except (FileNotFoundError,ProcessLookupError):pass
        except PermissionError:
            # Privilege-separated sshd children are non-dumpable. Do not silently
            # waive an inaccessible simulator or user script.
            comm=(proc/'comm').read_text().strip()
            if comm not in ('sshd','(sd-pam)'):raise
            PROTECTED_DAEMONS.add((proc.name,comm))
    return found

def dedupe(src,dst):
    total=0
    with open(src,'rb') as a,open(dst,'r+b') as b:
        size=os.fstat(a.fileno()).st_size
        for off in range(0,size,CHUNK):
            n=min(CHUNK,size-off)
            # linux/fs.h: 24-byte range header followed by one 32-byte dest entry.
            buf=bytearray(struct.pack('=QQHHIqQQiI',off,n,1,0,0,b.fileno(),off,0,0,0))
            fcntl.ioctl(a.fileno(),FIDEDUPERANGE,buf,True)
            _,_,count,status,_=struct.unpack_from('=qQQiI',buf,24)
            if status!=0 or count!=n:raise RuntimeError((str(dst),off,n,count,status))
            total+=count
        os.fsync(b.fileno())
    return total

if __name__=='__main__':
    if platform.node().split('.')[0]!='eex005':raise RuntimeError('Wrong host')
    if (OUT/'dedupe_receipt.json').exists():raise RuntimeError('Receipt already exists')
    # First verify that sharing does not alias later writes.
    a,b=OUT/'cow_probe_a',OUT/'cow_probe_b'
    payload=os.urandom(1024**2+123)
    a.write_bytes(payload);b.write_bytes(payload)
    dedupe(a,b)
    assert a.stat().st_ino!=b.stat().st_ino
    with b.open('r+b') as f:f.write(bytes([payload[0]^255]))
    assert a.read_bytes()==payload and b.read_bytes()!=payload
    a.unlink();b.unlink()
    plans=[]
    for root in json.loads((OUT/'duplicates.json').read_text()):
        for group in root['groups']:
            # Preserve upstream Git trees as-is. Only frozen experiment artifacts.
            if any('/vendor-restore-' in e['path'] for e in group['files']):continue
            entries=group['files']
            def rank(e):
                p=e['path']
                return (0 if '/llama16-full-006-csr-frontier/' in p or '/postrun-006-attribution-' in p else 1,p)
            entries=sorted(entries,key=rank)
            plans.append({'canonical':entries[0],'copies':entries[1:],'sha256':group['sha256']})
    paths=[e['path'] for p in plans for e in [p['canonical'],*p['copies']]]
    active=live_refs(paths)
    if active:raise RuntimeError(('Active references',active))
    for plan in plans:
        for e in [plan['canonical'],*plan['copies']]:
            p=Path(e['path']);s=p.stat()
            if p.is_symlink() or (s.st_size,s.st_ino,s.st_mtime_ns)!=(e['bytes'],e['inode'],e['mtime_ns']):
                raise RuntimeError('File changed: '+str(p))
    (OUT/'dedupe_plan.json').write_text(json.dumps(plans,indent=2)+'\n')
    receipt={'method':'XFS FIDEDUPERANGE; independent inodes and copy-on-write',
             'cow_probe_passed':True,'live_references':active,'free_before':free(),'entries':[],
             'protected_session_daemons_not_inspectable':sorted(PROTECTED_DAEMONS),
             'source_files_deleted':0,'unique_results_deleted':0}
    with (OUT/'dedupe_journal.jsonl').open('x') as journal:
        for plan in plans:
            for e in plan['copies']:
                count=dedupe(plan['canonical']['path'],e['path'])
                record={'canonical':plan['canonical']['path'],'copy':e['path'],
                        'sha256':plan['sha256'],'deduplicated_bytes':count}
                journal.write(json.dumps(record)+'\n');journal.flush()
                receipt['entries'].append(record)
    for plan in plans:
        for e in [plan['canonical'],*plan['copies']]:
            p=Path(e['path']);s=p.stat()
            assert (s.st_size,s.st_ino,s.st_mtime_ns)==(e['bytes'],e['inode'],e['mtime_ns']),str(p)
            assert digest(p)==plan['sha256'],str(p)
    receipt.update(free_after=free(),all_sha256_verified=True,inodes_sizes_mtimes_preserved=True,
                   total_deduplicated_bytes=sum(e['deduplicated_bytes'] for e in receipt['entries']))
    receipt['observed_free_delta']=receipt['free_after']-receipt['free_before']
    (OUT/'dedupe_receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps({k:v for k,v in receipt.items() if k!='entries'},indent=2),flush=True)
