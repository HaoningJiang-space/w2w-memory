"""Restore one retired test source, including pinned nested repositories."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess

parser=argparse.ArgumentParser()
parser.add_argument('batch')
parser.add_argument('--destination',type=Path)
args=parser.parse_args()
archive=Path(__file__).resolve().parent
plan=json.loads((archive/'RESTORE.json').read_text())
entry=next(e for e in plan['entries'] if Path(e['path']).parent.name==args.batch)
dest=args.destination or Path(entry['path'])
if dest.exists():raise SystemExit('Refusing to overwrite '+str(dest))
for repo in entry['repositories']:
    bundle=Path(repo['bundle'])
    if hashlib.sha256(bundle.read_bytes()).hexdigest()!=repo['bundle_sha256']:
        raise SystemExit('Bundle checksum mismatch')
    path=dest/repo['relative_path']
    if path.exists() and any(path.iterdir()):raise SystemExit('Nonempty restore destination')
    path.parent.mkdir(parents=True,exist_ok=True)
    subprocess.run(['git','clone','--no-checkout',str(bundle),str(path)],check=True)
    if repo['shallow_commits']:
        (path/'.git/shallow').write_text('\n'.join(repo['shallow_commits'])+'\n')
    subprocess.run(['git','-C',str(path),'checkout','--detach',repo['head']],check=True)
    subprocess.run(['git','-C',str(path),'fsck','--full'],check=True)
    tree=subprocess.check_output(['git','-C',str(path),'rev-parse','HEAD^{tree}'],text=True).strip()
    assert tree==repo['tree']
assert not subprocess.check_output(['git','-C',str(dest),'status','--porcelain'],text=True).strip()
print('RESTORED '+str(dest))
