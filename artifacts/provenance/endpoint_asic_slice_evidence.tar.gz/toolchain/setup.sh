#!/bin/bash
set -e
cd /Projects/haoning/w2w-memory-slice-20261007/asic_tools
trap 'status=$?; printf "%s\n" "$status" > setup_status' EXIT
curl --fail --location --retry 2 --connect-timeout 20 https://micro.mamba.pm/api/micromamba/linux-64/latest -o micromamba.tar.bz2
sha256sum micromamba.tar.bz2 > bootstrap.sha256
tar xjf micromamba.tar.bz2 bin/micromamba
export MAMBA_ROOT_PREFIX="$PWD/mamba"
bin/micromamba create -y -p "$PWD/env" -c conda-forge --override-channels 'python=3.11' 'yosys=0.69' 'verilator=5.052' 'cmake>=3.24' 'swig>=4' 'tk=8.6' bison flex 'eigen=3.4' 'fmt=8.1.1'
bin/micromamba list -p "$PWD/env" --explicit > environment.explicit.txt
