#!/bin/bash
set -e
cd /Projects/haoning/w2w-memory-slice-20261007/asic_tools
trap 'status=$?; printf "%s\n" "$status" > build_sta_status' EXIT
export PATH="$PWD/env/bin:$PATH"
export LD_LIBRARY_PATH="$PWD/env/lib:${LD_LIBRARY_PATH:-}"
export W2W_TOOLS="$PWD"
cd src/cudd
autoreconf -fi
./configure --prefix="$W2W_TOOLS/cudd_install" --enable-shared=no CFLAGS='-O2 -fPIC' > "$W2W_TOOLS/cudd_configure.log" 2>&1
make -j2 > "$W2W_TOOLS/cudd_build.log" 2>&1
make install > "$W2W_TOOLS/cudd_install.log" 2>&1
cd "$W2W_TOOLS"
cmake -S src/OpenSTA -B sta_build -G Ninja -DCMAKE_BUILD_TYPE=Release -DCMAKE_PREFIX_PATH="$PWD/env" -DCUDD_DIR="$PWD/cudd_install" -DTCL_LIBRARY="$PWD/env/lib/libtcl8.6.so" -DTCL_HEADER="$PWD/env/include" -DCMAKE_INSTALL_PREFIX="$PWD/env" > sta_configure.log 2>&1
cmake --build sta_build --parallel 2 > sta_build.log 2>&1
cmake --install sta_build > sta_install.log 2>&1
sta -version
yosys -V
verilator --version
