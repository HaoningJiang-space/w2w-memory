# User-space ASIC tools; no shell-profile or system-package changes.
export PATH="/Projects/haoning/w2w-memory-slice-20261007/asic_tools/env/bin:$PATH"
export LD_LIBRARY_PATH="/Projects/haoning/w2w-memory-slice-20261007/asic_tools/env/lib:${LD_LIBRARY_PATH:-}"
