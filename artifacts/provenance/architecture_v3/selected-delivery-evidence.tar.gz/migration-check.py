import sys,json,tempfile
from pathlib import Path
sys.path.insert(0,sys.argv[1])
from w2w.architecture.presets import vertical_memory
from w2w.architecture.compiler import compile_machine
from w2w.workloads.moe import build_moe
from w2w.mapping.data_placement import place_weights
from w2w.mapping.compute_placement import place_compute
from w2w.mapping.lowering import lower
from w2w.backends.ramulator import VerticalRWDL
from w2w.system.kernel import execute_system
try:
 from w2w.backends.booksim.adapter import factory
except ImportError:
 from w2w.network.booksim_backend import factory
rows={}
for org in ('central','distributed','external'):
 stack=vertical_memory(org);machine=compile_machine(stack)
 logical=build_moe(((0,),),experts=4,topk=1,intermediate=512)
 weights=place_weights(logical,stack);placement=place_compute(logical,stack,weights)
 graph,meta=lower(logical,machine,weights,placement);native=VerticalRWDL(machine,refresh=False)
 try:
  with tempfile.TemporaryDirectory() as directory:
   r=execute_system(machine,graph,native=native,time_advance='boundaries',max_ps=1000000000,
    activation_sram_read_bytes_per_cycle=128,network_factory=factory(binary=Path(sys.argv[2]),directory=Path(directory)/'net',local_dma='payload_beats',cell_sideband_bits=64))
   rows[org]={k:r[k] for k in ('makespan_ps','drained_ps','tasks','sram_peak_bytes','compute_busy_ps','engine_context_ps','mc_pool_peak')}
   rows[org]['network']={k:r['network'][k] for k in ('link_flits','source_peak_flits','rx_write_cycles','accepted_packets','delivered_packets')}
   rows[org]['native']={k:r['native'][k] for k in ('config_sha256','completed_atoms','native_last_tail_ps','channel_atoms','gateway_bytes')}
 finally:native.close()
Path(sys.argv[3]).write_text(json.dumps(rows,sort_keys=True))
print({k:v['makespan_ps'] for k,v in rows.items()})
