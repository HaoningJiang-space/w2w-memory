from pathlib import Path
import json,hashlib,tarfile,gzip
root=Path('/Projects/haoning/w2w-full-system-v3-20261009')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
small=['final-analysis.json','final-analysis.log','final-tests.log','final-source-audit.json','compile-machine.log','p1-tests.log','p3-tests.log','p5-micro-tests.log','p6-tests.log','p6-build.log','p2-build.log','p4-build.log','equivalence-old.json','equivalence-new.json','migration-before.json','migration-after.json','invalidated-external-v1.json','periodic-checks-v1.log','periodic-checks-edge-v1.log','native-p2/build-manifest.json','native-p4/build-manifest.json','native-p6/build-manifest.json']
files=[root/p for p in small]
files += [p for p in (root/'compiled-final-machine').rglob('*') if p.is_file()]
runs={}
for case,study in [('central','study-v1'),('distributed','study-v1'),('external','edge-study-v1')]:
 base=root/study;path=base/'cases'/case
 files.extend([base/'registration.json',base/'inputs'/f'{case}.json',path/'summary.json',path/'completion.json',base/'logs'/f'{case}.log'])
 completion=json.loads((path/'completion.json').read_text())
 raw=path/'result.json.gz'
 with gzip.open(raw,'rt') as f: executed=json.load(f)
 runs[case]={'booksim_identity':executed['network']['identity'],'runtime_source':executed['network']['runtime_source'],'source_commit':completion['source_commit'],'input_sha256':completion['input_sha256'],'archive_directory':str(base),'raw_result':{'path':str(raw),'sha256':sha(raw),'bytes':raw.stat().st_size},'makespan_ps':completion['makespan_ps'],'audit':completion['audit']}
script=root/'migration-check.py';files.append(script)
files.append(root/'delivery-script.py')
files=sorted(set(files))
manifest={'schema':'w2w.v3-delivery-evidence.v1','verification_source_commit':'f20f7d5','server':'hn072@143.89.78.72','root':str(root),'runs':runs,'selected_files':{str(p.relative_to(root)):{'sha256':sha(p),'bytes':p.stat().st_size} for p in files},'native_builds':{n:json.loads((root/n/'build-manifest.json').read_text())['outputs'] for n in ('native-p2','native-p4','native-p6')},'migration':{'old_graph_native_equal':(root/'equivalence-old.json').read_bytes()==(root/'equivalence-new.json').read_bytes(),'v3_package_move_events_equal':(root/'migration-before.json').read_bytes()==(root/'migration-after.json').read_bytes()},'raw_capture_policy':'Large raw executions and builds remain on server; source recovered via annotated tags.'}
mp=root/'delivery-manifest.json';mp.write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
with tarfile.open(root/'selected-delivery-evidence.tar.gz','w:gz') as tar:
 for p in files+[mp]:tar.add(p,arcname=str(p.relative_to(root)),recursive=False)
print(json.dumps({'migration':manifest['migration'],'archive_bytes':(root/'selected-delivery-evidence.tar.gz').stat().st_size,'runs':{k:v['makespan_ps'] for k,v in runs.items()}}))
comm=Path('/Projects/haoning/w2w-full-system-communication-20261009')
files=[comm/p for p in ('analysis.json','analysis.log','tests-narrow-cc.log','planned-resources.json','periodic-checks.log','study/registration.json')]
for case in ('gather-stream','near-shard-stream'):
 files.extend([comm/'study/inputs'/f'{case}.json',comm/'study/cases'/case/'summary.json',comm/'study/cases'/case/'completion.json',comm/'study/logs'/f'{case}.log'])
report=json.loads((comm/'analysis.json').read_text())
print('communication keys',list(report))
with tarfile.open(comm/'selected-delivery-evidence.tar.gz','w:gz') as tar:
 for p in files:tar.add(p,arcname=str(p.relative_to(comm)),recursive=False)
